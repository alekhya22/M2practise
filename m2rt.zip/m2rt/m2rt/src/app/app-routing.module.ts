import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeelistComponent } from './employeelist/employeelist.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { SearchemployeeComponent } from './searchemployee/searchemployee.component';


const routes: Routes = [
  {
    path: 'app-employeelist',
    component: EmployeelistComponent
  },
  
  {
    path: 'app-addemployee',
    component: AddemployeeComponent
  },
  {
    path: 'app-searchemployee',
    component: SearchemployeeComponent
  },
  { path: '', redirectTo: '/app-employeelist', pathMatch: 'full' }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
