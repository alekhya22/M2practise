import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: ['./employeelist.component.css']
})
export class EmployeelistComponent implements OnInit {

  id: number;
  name: string;
  email: string;
  phoneno: number;
  employee: Employee[] = [];
  employeeService: EmployeeService;
  constructor(employeeService: EmployeeService) {
    this.employeeService = employeeService;
  }

  ngOnInit() {
    this.employeeService.fetchdata();
    this.employee = this.employeeService.getEmployee();
  }
  delete(index: number) {
    this.employeeService.deleteEmployee(index);
  }
  updateboo: boolean = true;
  Updatedata(dat: Employee) {
    this.employeeService.UpdateData(dat);

  }
  update(p1: Employee) {
    this.updateboo = !this.updateboo;
    this.id = p1.id;
    this.name = p1.name;
    this.email = p1.email;
    this.phoneno = p1.phoneno;


  }

}
