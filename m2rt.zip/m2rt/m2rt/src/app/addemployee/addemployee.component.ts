import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';
import { Router } from'@angular/router';    






@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {

  employeeService: EmployeeService;
  router: Router;
  constructor(employeeService: EmployeeService,router:Router) {
    this.employeeService = employeeService;
    this.router = router
  }

  ngOnInit() {
  }
  add(emp: Employee) {
    let empObj = new Employee(emp.id, emp.name, emp.email, emp.phoneno);
    this.employeeService.addEmployee(empObj);
    this.router.navigateByUrl('app-employeelist');
  }

}
