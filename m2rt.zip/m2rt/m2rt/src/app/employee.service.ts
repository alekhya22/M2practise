import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from './Employee';



@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  http: HttpClient;
  fetch: boolean = false;
  employee = [];
  router: any;


  constructor(http: HttpClient) {
    this.http = http;
  }
  fetchdata() {
    this.http.get('../assets/employee.json').subscribe(
      data => {
        if (!this.fetch) {
          this.convert(data);
          this.fetch = true;
        }
      }
    )
  }
  convert(data: any) {
    for (let emp of data) {
      let empObj = new Employee(emp.id, emp.name, emp.email, emp.phoneno);
      this.employee.push(empObj);
    }
  }
  getEmployee(): Employee[] {
    return this.employee;
  }

  deleteEmployee(index: number) {
    let indexNum: number = this.employee.indexOf(index);
    alert("Are You Sure You want to delete?"); 
    if (indexNum !== -1) {
      this.employee.splice(indexNum, 1);
    }
  }
  addEmployee(e: Employee) {
    this.employee.push(e);
    
  }
  UpdateData(dat: Employee) {
    let pid = dat.id;
    for (let i = 0; i < this.employee.length; i++) {
      if (pid == this.employee[i].id) {
        this.employee[i].id = dat.id;
        this.employee[i].name = dat.name;
        this.employee[i].email = dat.email;
        this.employee[i].phoneno = dat.phoneno;

      }

    }



  }
  empl: Employee[];
  SearchEmployee(p3): Employee[] {
    this.empl = [];
    for (let po of this.employee) {
      if (po.id == p3.id) {
        this.empl.push(po);
      }
    }
    return this.empl;
  }

}
