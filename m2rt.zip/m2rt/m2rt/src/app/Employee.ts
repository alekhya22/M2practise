export class Employee {
    id: number;
    name: string;
    email: string;
    phoneno: number;
    constructor(id: number, name: string, email: string, phoneno: number) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phoneno = phoneno;
    }

}