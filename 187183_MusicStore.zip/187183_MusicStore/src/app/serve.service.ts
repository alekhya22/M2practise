import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ServeService {

  http : HttpClient;
  list : List[] = [];
  
  constructor(http : HttpClient) {
    this.http = http;
   }

   add(list : List){
     this.list.push(list);
   }

   getList() : List[]{
     return this.list;
   }

   delete(id){
     let index = this.getList().indexOf(id);
     alert("Are You Sure You want to delete?");  
     this.list.splice(index , 1);
   }
}

export class List{
  id : number;
  title : string;
  artist : string;
  price : number;
  
  constructor( id : number, title : string, artist : string, price : number){
    this.id = id;
    this.title = title;
    this.artist = artist;
    this.price = price;
  }
}
