import { Component, OnInit } from '@angular/core';
import { ServeService } from '../serve.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  service : ServeService;
  router: Router;

  constructor(service : ServeService, router : Router) { 
    this.service = service;
    this.router = router;
  }

  add(data : any){
    if(data.id!="" && data.title!="" && data.artist!="" && data.price!=""){
    this.service.add(data);
    this.router.navigateByUrl('app-list');
    
    }
    else{
      window.alert("Enter the details properly");
    }
  }

  ngOnInit() {
  }

}
