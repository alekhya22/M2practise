import { Component, OnInit } from '@angular/core';
import { ServeService, List } from '../serve.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  service : ServeService;
  list : List[] = [];
  
  constructor(service : ServeService) {
    this.service = service;
   }

  ngOnInit() {
    this.list = this.service.getList();
  }

  delete(id){
    this.service.delete(id);
  }

}
