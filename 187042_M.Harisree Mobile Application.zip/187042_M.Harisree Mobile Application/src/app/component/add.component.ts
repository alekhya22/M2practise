import { Component, OnInit } from '@angular/core';
import { MobileService } from '../service/mobile.service';
import { Router } from '@angular/router';
import { Mobile } from '../mobile';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
/**
 * mobileData is the object to class Mobile
 */
  mobileData: Mobile={"id":0,"name":'',"price":0,"brand":''};
  constructor(private mobileService:MobileService,private router:Router) { }

  ngOnInit() {
  }
 /**
  * 
  * addMobile() is used to add the mobile data 
  */
  addMobile(mobile:Mobile){
 

this.mobileService.addMobile(mobile);
this.router.navigate(['show']);
  }}