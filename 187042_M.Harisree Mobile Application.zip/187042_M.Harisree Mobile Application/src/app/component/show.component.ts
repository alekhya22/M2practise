import { Component, OnInit } from '@angular/core';
import { MobileService } from '../service/mobile.service';
import { Mobile } from '../mobile';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
 mobiles:Mobile[]=[];

  constructor(private mobileService:MobileService) { }

  /**
   * ngOnit is used to load the data
   */

  ngOnInit() {
    this.mobiles=this.mobileService.getAllMobiles();
  }
  /**
   * 
   * 
   * here delete method is used to delete a row by using the parameter i
   */
delete(i:number){
  
  this.mobileService.deleteEmployee(i);
 
  }
}
  
  
  

