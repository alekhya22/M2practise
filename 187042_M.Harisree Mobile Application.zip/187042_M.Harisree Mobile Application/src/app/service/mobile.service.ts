import { Injectable } from '@angular/core';
import { Mobile } from '../mobile';


@Injectable({
  providedIn: 'root'
})
export class MobileService {
  private mobiles:Mobile[]=[
   
  ];
  constructor() { }
  /**
   * getAllMobiles is used retrieve all the details of mobile
   */
  getAllMobiles():Mobile[]{
    return this.mobiles;
  }
  /**
   * 
   * add mobile() is used to add the records of mobile in a row
   */
  addMobile(mobile:Mobile){
    this.mobiles.push(mobile);
    return true;
  }
  /**
   * 
   * delete method is used to delete a row 
   */
  deleteEmployee(i:number){
       this.mobiles.splice(i,1);
  }

}
