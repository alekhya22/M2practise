import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddComponent } from './component/add.component';
import { ShowComponent } from './component/show.component';

const routes: Routes = [
  {path:"add",component:AddComponent},
  {path:"show",component:ShowComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
