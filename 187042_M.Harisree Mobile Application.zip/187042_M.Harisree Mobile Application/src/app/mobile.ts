export class Mobile {
    id:number;
    name:string;
    price:number;
    brand:string
}
